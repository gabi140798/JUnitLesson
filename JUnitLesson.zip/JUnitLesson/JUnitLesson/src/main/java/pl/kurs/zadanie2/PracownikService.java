package pl.kurs.zadanie2;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

public class PracownikService {

}
