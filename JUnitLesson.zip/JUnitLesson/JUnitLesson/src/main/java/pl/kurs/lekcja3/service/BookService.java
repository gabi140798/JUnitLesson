package pl.kurs.lekcja3.service;

public class BookService {
}
