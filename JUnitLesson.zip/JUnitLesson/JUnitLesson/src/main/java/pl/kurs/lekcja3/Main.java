package pl.kurs.lekcja3;

public class Main {
    public static void main(String[] args) {


        /*
        stworz dwie klasy Autor i Ksiazka
        ascjacja jeden do wiele
        znajdz najstarszego autora
        znajdz autorow starszych niz podany wiek
        znajdz najstarszego autora, ktory wydal wiecej niz 2 ksiazki
        zwroc wszystkie ksiazki wydane po dacie podanej jako parametr
         */
    }
}
