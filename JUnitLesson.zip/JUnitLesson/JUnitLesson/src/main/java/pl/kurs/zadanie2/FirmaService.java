package pl.kurs.zadanie2;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

public class FirmaService {

    public double wyplataDlaWszystkichPracownikow(Firma firma) {
        return Optional.ofNullable(firma.getListaPracownikow())
                .orElse(Collections.emptyList())
                .stream()
                .filter(Objects::nonNull)
                .mapToDouble(Pracownik::getPensja)
                .sum();
    }
}
