package pl.kurs.lekcja2.service;

public class BookService {
}
