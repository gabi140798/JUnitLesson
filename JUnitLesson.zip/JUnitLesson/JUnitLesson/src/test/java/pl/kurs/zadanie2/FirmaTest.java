package pl.kurs.zadanie2;

import static org.junit.Assert.*;

public class FirmaTest {

}